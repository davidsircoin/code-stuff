skyffla :: [a] -> [a]
skyffla [] = []
skyffla list = [x | (n, x) <- zip [0 ..] list, even n] ++ skyffla [x | (n, x) <- zip [0 ..] list, odd n]
