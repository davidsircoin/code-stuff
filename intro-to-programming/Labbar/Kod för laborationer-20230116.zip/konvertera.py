
def fahrenheit_to_celsius(t):
    t_celsius = 0
    return t_celsius

svar = input('Ange en temperatur i Fahrenheit: ')
t_fahrenheit = float(svar)
t = fahrenheit_to_celsius(t_fahrenheit)
print("Celsius: ", t)
