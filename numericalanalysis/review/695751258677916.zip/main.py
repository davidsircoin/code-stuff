#!/usr/bin/env python3

with open("README.txt") as h:
    print(h.read())
